	
var ctx, color = "#000";	

var isCaliClicked = false;
var isPilgiClicked = false;

document.addEventListener( "DOMContentLoaded", function(){
	// setup a new canvas for drawing wait for device init
    setTimeout(function(){
	   newCanvas();
    }, 100);
}, false );

// function to setup a new canvas for drawing
function newCanvas(){
	//define and resize canvas
    document.getElementById("content").style.height = window.innerHeight;
    var canvas = '<canvas id="canvas" width="'+window.innerWidth+'" height="'+(window.innerHeight)+'"></canvas>';
	document.getElementById("content").innerHTML = canvas;

	console.error("window.innerHeight: " + window.innerHeight);
    
    // setup canvas
	ctx=document.getElementById("canvas").getContext("2d");
	ctx.strokeStyle = color;
	ctx.lineWidth = 5;
	
	// setup to trigger drawing on mouse or touch
    drawTouch();
    drawPointer();
	drawMouse();
}
        
function selectColor(el){
    //for(var i=0;i<document.getElementsByClassName("palette").length;i++){
        //document.getElementsByClassName("palette")[i].style.borderColor = "#777";
        //document.getElementsByClassName("palette")[i].style.borderStyle = "solid";
    //}
    //el.style.borderColor = "#fff";
    //el.style.borderStyle = "dashed";

    color = window.getComputedStyle(el).backgroundColor;
    console.error(color)
    ctx.beginPath();
    ctx.strokeStyle = color;
}

// prototype to	start drawing on touch using canvas moveTo and lineTo
var drawTouch = function() {
	var start = function(e) {
		ctx.beginPath();
		x = e.changedTouches[0].pageX;
		y = e.changedTouches[0].pageY;
		ctx.moveTo(x,y);
	};
	var move = function(e) {
		e.preventDefault();
		x = e.changedTouches[0].pageX;
		y = e.changedTouches[0].pageY;
		ctx.lineTo(x,y);
		ctx.stroke();
	};
    document.getElementById("canvas").addEventListener("touchstart", start, false);
	document.getElementById("canvas").addEventListener("touchmove", move, false);
}; 
    
// prototype to	start drawing on pointer(microsoft ie) using canvas moveTo and lineTo
var drawPointer = function() {
	var start = function(e) {
        e = e.originalEvent;
		ctx.beginPath();
		x = e.pageX;
		y = e.pageY;
		ctx.moveTo(x,y);
	};
	var move = function(e) {
		e.preventDefault();
        e = e.originalEvent;
		x = e.pageX;
		y = e.pageY;
		ctx.lineTo(x,y);
		ctx.stroke();
    };
    document.getElementById("canvas").addEventListener("MSPointerDown", start, false);
	document.getElementById("canvas").addEventListener("MSPointerMove", move, false);
};        

// prototype to	start drawing on mouse using canvas moveTo and lineTo
var drawMouse = function() {
	var clicked = 0;
	var start = function(e) {
		clicked = 1;
		ctx.beginPath();
		x = e.pageX;
		y = e.pageY;
		ctx.moveTo(x,y);
	};
	var move = function(e) {
		if(clicked){
			x = e.pageX;
			y = e.pageY;
			ctx.lineTo(x,y);
			ctx.stroke();
		}
	};
	var stop = function(e) {
		clicked = 0;
	};
    document.getElementById("canvas").addEventListener("mousedown", start, false);
	document.getElementById("canvas").addEventListener("mousemove", move, false);
	document.addEventListener("mouseup", stop, false);
};



function scalePreserveAspectRatio(imgW,imgH,maxW,maxH){
  return(Math.min((maxW/imgW),(maxH/imgH)));
}

var drawBackgroundImg = function(){

	console.error('back img w: ' + window.innerWidth);
	console.error('back img innerHeightw: ' + window.innerHeight);
    var img = new Image();
    img.onload=function(){
        ctx.drawImage(img,0,0,img.width,img.height,0,0,window.innerWidth,window.innerHeight);
    }
    img.src="/img/background1.jpg";
}

var captureClick = function(){

	drawBackgroundImg();
	var timer;
	$('.capture_btn').on("touchstart",function(){
	    timer = setTimeout(function(){
	        window.location.reload(true);
	    },1000);
	}).on("touchend",function(){
	    clearTimeout(timer);
	});
}

var printCaligraphyImg = function(){
	$('#cali_option').css('height', '0px');
	console.log('printCaligraphyImg()');
	newCanvas();
	//drawBackgroundImg();
	var img = new Image();
    img.onload=function(){
        ctx.drawImage(img,0,0,img.width,img.height,0,0,window.innerWidth,window.innerHeight);
        var imgCali = document.getElementById("caligraphy_final");
    	ctx.drawImage(imgCali,10,10);
    }
    img.src="/img/background1.jpg";



    $(".select_option").css("font-size", (window.innerWidth/70)+"pt")
	$(".select_option").fadeIn( "slow", function(){  //select_option
		console.log('fade in is called');
	});
	setTimeout(function(){ 
		$(".select_option").fadeOut( "slow", function(){
			console.log('fade out is called');
	  	});
	}, 2000);

    $('.cali_btn').css('display', 'none');
    $('.pilgi_btn').css('display', 'none');
    $('.copy_btn').css('visibility', 'visible');
    $('.print_btn').css('visibility', 'visible');
}

var refresh = function(){
	$('.cali_btn').css('visibility', 'visible');
    $('.pilgi_btn').css('visibility', 'visible');
    $('.copy_btn').css('display', 'none');
    $('.print_btn').css('display', 'none');
}

var printPilgiImg = function(){
	$('#pilgi_option').css('height', '0px');
	newCanvas();
	var img = new Image();
    img.onload=function(){
        ctx.drawImage(img,0,0,img.width,img.height,0,0,window.innerWidth,window.innerHeight);
        var imgCali = document.getElementById("pilgi_final");
    	ctx.drawImage(imgCali,10,10);
    }
    img.src="/img/background1.jpg";


    $(".select_option").css("font-size", (window.innerWidth/70)+"pt")
	$(".select_option").fadeIn( "slow", function(){  //select_option
		console.log('fade in is called');
	});
	setTimeout(function(){ 
		$(".select_option").fadeOut( "slow", function(){
			console.log('fade out is called');
	  	});
	}, 2000);


    $('.cali_btn').css('display', 'none');
    $('.pilgi_btn').css('display', 'none');
    $('.copy_btn').css('visibility', 'visible');
    $('.print_btn').css('visibility', 'visible');
}

var copyClick = function(){
	window.location.reload(true);
}


var caligraphyClick = function(){
	console.log('caligraphyClick');
    $('.cali_opt_item').click(function() {
        var id = $(this).attr("id");
        console.log("clicked id " + id);
        if(id == 'cali_exit'){
        	$('#cali_option').css('height', '0px');
        } else {
        	printCaligraphyImg();
        }
    });

    if(!isCaliClicked){
		$(".finalLoading").fadeIn( "slow", function(){
			console.log('fade in is called');
	  	});

		setTimeout(function(){ 
			$(".finalLoading").fadeOut( "slow", function(){
				console.log('fade out is called');
				$('#cali_option').css('height', '40%');
	  		});
		}, 2000);
    	isCaliClicked = true;
    } else {
    	var height = $("#cali_option").height();
        if( height == 0 ) {
            $('#cali_option').css('height','40%');
        } 
        else {
            $('#cali_option').css('height', '0px');
        }
    }
}

var pilgiClick = function(){

    $('.pilgi_opt_item').click(function() {
        var id = $(this).attr("id");
	    if(id == 'pilgi_exit'){
	    	$('#pilgi_option').css('height', '0px');
	    } else {
	        printPilgiImg();
	    }
    });

    // var height = $("#pilgi_option").height();
    //     if( height == 0 ) {
    //         $('#pilgi_option').css('height','40%');
    //     } 
    //     else {
    //         $('#pilgi_option').css('height', '0px');
    //     }

    if(!isPilgiClicked){
		$(".finalLoading").fadeIn( "slow", function(){  //select_option
			console.log('fade in is called');
	  	});

		setTimeout(function(){ 
			$(".finalLoading").fadeOut( "slow", function(){
				console.log('fade out is called');
				$('#pilgi_option').css('height', '40%');
	  		});
		}, 2000);
    	isPilgiClicked = true;
    } else {
    	var height = $("#pilgi_option").height();
        if( height == 0 ) {
            $('#pilgi_option').css('height','40%');
        } 
        else {
            $('#pilgi_option').css('height', '0px');
        }
    }



}

var printClick = function(){
	console.log('printClick()');
	$(".finalLoading").fadeIn( "slow", function(){
		console.log('fade in is called');
  	});

	setTimeout(function(){ 
		$(".finalLoading").fadeOut( "slow", function(){
			console.log('fade out is called');
		$(".select_option").css("font-size", (window.innerWidth/90)+"pt")
		$(".select_option").html('프린터 준비가 완료되었습니다.')
		$(".select_option").fadeIn( "slow", function(){  //select_option
			console.log('fade in is called');
		});
		setTimeout(function(){ 
			$(".select_option").fadeOut( "slow", function(){
				console.log('fade out is called');
		  	});
		}, 2000);


  		});
	}, 2000);


	
}